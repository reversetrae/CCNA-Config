# Build guide (Cisco Packet Tracer)

Tested against the device models listed below. Packet Tracer 8.x or later is recommended.

## 1. Place the devices

| Device | Packet Tracer model | Notes |
|---|---|---|
| ISP | ISR4331 | |
| R1 | ISR4331 | |
| DSW1, DSW2 | 3650-24PS | **Ships with no power supply.** Open the device, go to the **Physical** tab, and drag an **AC-POWER-SUPPLY** into the empty slot, or the switch stays off. |
| ASW1, ASW2 | 2960-24TT | |
| PC1–PC4 | PC-PT | Set IP Configuration to **DHCP** after the configs are in |

## 2. Cable it

Use copper straight-through cables for every link.

| From | Port | To | Port |
|---|---|---|---|
| ISP | G0/0/0 | R1 | G0/0/0 |
| R1 | G0/0/1 | DSW1 | G1/1/1 |
| R1 | G0/0/2 | DSW2 | G1/1/1 |
| DSW1 | G1/0/23 | DSW2 | G1/0/23 |
| DSW1 | G1/0/24 | DSW2 | G1/0/24 |
| DSW1 | G1/0/1 | ASW1 | G0/1 |
| DSW1 | G1/0/2 | ASW2 | G0/1 |
| DSW2 | G1/0/1 | ASW1 | G0/2 |
| DSW2 | G1/0/2 | ASW2 | G0/2 |
| ASW1 | Fa0/1 | PC1 | Fa0 |
| ASW1 | Fa0/2 | PC2 | Fa0 |
| ASW2 | Fa0/1 | PC3 | Fa0 |
| ASW2 | Fa0/2 | PC4 | Fa0 |

> G1/1/1 on the 3650 is an uplink port. If Packet Tracer won't connect a copper cable to it, use a fiber cable, or move the R1 link to G1/0/20 and update the interface name in the DSW config.

## 3. Load the configs

Paste each file from `configs/` into the device's CLI tab, in this order:

1. `ISP.txt`
2. `R1.txt`
3. `DSW1.txt`, then `DSW2.txt`
4. `ASW1.txt`, then `ASW2.txt`

Tips:
- Paste one section at a time if the CLI drops lines. Packet Tracer's buffer can't take very long pastes.
- If `crypto key generate rsa` prompts for a size, type `2048`.
- If a 3650 rejects `switchport trunk encapsulation dot1q`, ignore the error. That model only supports 802.1Q, so the line isn't needed.
- Replace the `CHANGE_ME_*` placeholders with your own lab passwords on the devices, but **don't commit them**.

## 4. Let it converge

Click **Fast Forward Time** a few times, or wait about a minute, so spanning tree, OSPF, and HSRP can settle. Then set each PC to DHCP and confirm it gets an address in its VLAN.

## 5. Capture evidence

For each test in [verification.md](verification.md), save the command output to a text file in `verification/` (for example `verification/T4-DSW1-show-standby-brief.txt`).

If you save full `show running-config` output, run it through the sanitizer before committing:

```bash
python3 scripts/sanitize_config.py verification/*.txt
```

Save the lab as `campus.pkt` in the repo root, and save a screenshot of the topology as `diagrams/topology.png`.
