# Verification plan

Run each test, save the output to `verification/` (file name in the **Evidence** column), and tick the result in the README.

| # | Test | Where | Command | Expected | Evidence |
|---|---|---|---|---|---|
| T1 | VLANs and trunks | ASW1, DSW1 | `show vlan brief`<br>`show interfaces trunk` | VLANs 10, 20, 30, 99, 666, 999 exist. Trunks show native 999 and allowed 10,20,30,99 | `T1-*.txt` |
| T2 | EtherChannel | DSW1 | `show etherchannel summary` | `Po1(SU)` with G1/0/23 and G1/0/24 flagged `(P)`; protocol LACP | `T2-DSW1.txt` |
| T3 | STP root placement | DSW1, DSW2 | `show spanning-tree vlan 10`<br>`show spanning-tree vlan 20` | DSW1: "This bridge is the root" for VLAN 10. DSW2: root for VLAN 20 | `T3-*.txt` |
| T4 | HSRP roles | DSW1, DSW2 | `show standby brief` | DSW1 Active for 10 and 99, Standby for 20 and 30. DSW2 the reverse | `T4-*.txt` |
| T5 | OSPF | R1, DSW1 | `show ip ospf neighbor`<br>`show ip route ospf` | R1 has two FULL neighbors. DSW1 has FULL with R1 (G1/1/1) and DSW2 (Vlan99). DSW1 shows `O*E2 0.0.0.0/0` | `T5-*.txt` |
| T6 | DHCP | PCs, R1, ASW1 | PC: `ipconfig`<br>R1: `show ip dhcp binding`<br>ASW1: `show ip dhcp snooping binding` | Each PC has an address from .11 up in its VLAN, gateway .1. Bindings on R1 and ASW1 | `T6-*.txt` |
| T7 | Inter-VLAN reachability | PC1 | `ping 10.10.20.x` (PC2)<br>`ping 10.10.10.x` (PC3) | Both succeed: PC1 to PC2 is routed between VLANs, PC1 to PC3 crosses switches in the same VLAN | `T7-PC1.txt` |
| T8 | Internet through PAT | PC1, R1 | PC1: `ping 8.8.8.8`<br>R1: `show ip nat translations` | Ping succeeds. Translations show inside local 10.10.10.x, inside global 203.0.113.2 | `T8-*.txt` |
| T9 | Guest isolation | PC4, DSW2 | `ping 8.8.8.8`<br>`ping 10.10.10.x` (PC1)<br>DSW2: `show access-lists GUEST-IN` | Internet succeeds, PC1 fails. ACL match counters increase on the deny line | `T9-*.txt` |
| T10 | Management plane | PC1, PC4 | PC1: `ssh -l netadmin 10.10.99.11`<br>PC1: `telnet 10.10.99.11`<br>PC4: `ssh -l netadmin 10.10.99.11` | PC1 SSH succeeds. Telnet is refused. PC4 is blocked | `T10-*.txt` |
| T11 | Port security | ASW1 | `show port-security interface fa0/1`<br>`show port-security address` | Secure-up, max 2, violation Restrict, PC1's MAC learned as sticky | `T11-ASW1.txt` |
