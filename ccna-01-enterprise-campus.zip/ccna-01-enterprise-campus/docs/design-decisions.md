# Design decisions

Each decision records what was chosen, what was rejected, and why.

## 1. Layer 3 at the distribution layer, layer 2 only at the access layer

**Decision:** The distribution switches route between VLANs and connect to the edge router over routed /30 links. Access switches are layer 2 only.

**Why:** Each VLAN's broadcast and spanning-tree domain ends at the distribution layer. The edge router never takes part in spanning tree, and routing between VLANs happens in the switch hardware instead of on a router-on-a-stick.

**Rejected:** Router-on-a-stick on R1. It's simpler, but every inter-VLAN packet would cross one router link, and that router would be a single point of failure.

## 2. HSRP load sharing, with the STP root following the active gateway

**Decision:** DSW1 is HSRP active for VLANs 10 and 99, and DSW2 is active for VLANs 20 and 30. For each VLAN, the spanning-tree root is the same switch as the active gateway. Both switches use `preempt`.

**Why:** Both distribution switches carry traffic instead of one sitting idle. Putting the root and the active gateway on the same switch keeps traffic on the direct uplink. If they were on different switches, frames would cross the inter-switch link to reach the gateway, and that suboptimal path is easy to miss.

**Rejected:** One switch active for every VLAN. It's easier to reason about, but it wastes half the capacity.

## 3. Single-area OSPF with `passive-interface default`

**Decision:** All devices are in OSPF area 0. Interfaces are passive by default, and adjacencies form only on the uplinks to R1 and on VLAN 99 between the two DSWs. R1 advertises the default route with `default-information originate`.

**Why:** Passive by default stops OSPF hellos on user VLANs, so a device plugged into a user port can't form an adjacency and inject routes. The VLAN 99 adjacency gives each DSW a backup path through its peer if its own uplink to R1 fails (see troubleshooting scenario 1).

**Rejected:** Static routes. They work at this size, but they don't fail over by themselves, and adding sites means editing every device.

## 4. Centralized DHCP on R1 with relay

**Decision:** DHCP pools live on R1. Each SVI forwards DHCP requests to R1's loopback with `ip helper-address`.

**Why:** It mirrors the usual enterprise pattern of one central DHCP server and relays everywhere else. It also keeps the pools off the redundant gateway pair, so they don't have to be split or synchronized between the two DSWs.

**Trade-off:** R1 becomes a dependency for new leases. In production, the DHCP server would be a redundant pair on a server network.

## 5. Trunk hardening against VLAN hopping

**Decision:** Every trunk uses native VLAN 999 (which carries no traffic), an explicit allowed list (10, 20, 30, 99), and `switchport nonegotiate`. Unused access ports go into VLAN 666 and are shut down.

**Why:** These close the two classic VLAN-hopping attacks. Switch spoofing needs DTP, which `nonegotiate` turns off. Double tagging needs the attacker's VLAN to be the native VLAN, which VLAN 999 rules out. VLAN 1 is not used for anything.

## 6. DHCP snooping with option 82 insertion disabled

**Decision:** DHCP snooping is on for VLANs 10, 20, and 30, trusted only on the uplinks, with `no ip dhcp snooping information option`.

**Why:** Snooping drops DHCP offers that arrive on user ports, which stops a rogue DHCP server. By default, though, the access switch adds option 82 to client requests with the relay address (giaddr) set to 0.0.0.0. The DSW relay agents then drop those requests, and every client fails to get an address. Turning off insertion avoids that. Troubleshooting scenario 6 reproduces this failure.

## 7. Guest isolation with an inbound ACL on the guest SVI

**Decision:** The `GUEST-IN` ACL on VLAN 30 allows DHCP and traffic within the guest subnet, denies all private (RFC 1918) destinations, and allows everything else.

**Why:** Denying all private ranges, not just the current internal subnets, means new internal networks are blocked automatically. The ACL sits inbound on both DSWs, so it keeps working after an HSRP failover.

**Rejected:** An ACL on R1. By then the traffic has already reached the internal routing table, and inter-VLAN traffic between guests and staff never passes through R1 at all.

## 8. PAT on the edge router

**Decision:** All of 10.10.0.0/16 is translated to R1's single public address. The ISP router has no routes back to 10.x, so a successful ping to 8.8.8.8 can only mean translation worked.

## What I'd change in production

| Area | Lab | Production |
|---|---|---|
| Guest isolation | SVI ACL | Separate VRF or a firewall zone, so guests never share the routing table |
| Edge access control | Port security | 802.1X with MAB fallback, Dynamic ARP Inspection, IP Source Guard |
| Authentication | Local users | AAA against TACACS+ or RADIUS, with local accounts as fallback only |
| Visibility | None | NTP, central syslog, SNMPv3 or streaming telemetry, NetFlow |
| Gateway failover | HSRP preempt | HSRP interface or object tracking, plus BFD for faster OSPF failover |
| Internet | Single ISP | Dual ISPs, with BGP or IP SLA-tracked default routes |
| Change management | Pasted configs | Templated configs in Git, pushed and verified by automation (Project 3) |
