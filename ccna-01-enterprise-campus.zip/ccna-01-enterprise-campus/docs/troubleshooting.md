# Break/fix scenarios

Each scenario injects one failure, records what breaks, how to find it, and how to fix it. Fill in the **Observed** lines with what actually happened in your lab, since Packet Tracer timing and output can differ from real hardware.

---

## 1. Distribution uplink failure

**Break:** On DSW1, `interface g1/1/1` → `shutdown`.

**Expected:** PC1 (VLAN 10, gateway on DSW1) keeps internet access. DSW1 loses its OSPF neighbor R1, but it still learns the default route from DSW2 over the VLAN 99 adjacency.

**Diagnose:**
- DSW1: `show ip ospf neighbor` (only DSW2 remains)
- DSW1: `show ip route 0.0.0.0` (next hop is now 10.10.99.3)
- PC1: `tracert 8.8.8.8` (the extra hop through DSW2 shows up)

**Fix:** `no shutdown`.

**Observed:**

---

## 2. Distribution switch failure (gateway failover)

**Break:** Start `ping -t 8.8.8.8` on PC1, then power off DSW1 (Physical tab).

**Expected:** DSW2 becomes HSRP Active for VLANs 10 and 99, and spanning tree reconverges toward DSW2. A few pings drop, then traffic resumes. When DSW1 comes back, `preempt` returns it to Active.

**Diagnose:** DSW2: `show standby brief`, `show spanning-tree vlan 10`

**Observed:** Pings lost: ___

---

## 3. Rogue DHCP server

**Break:** Connect a Server-PT to ASW1 Fa0/3 (`no shutdown`, `switchport access vlan 10`). Turn on its DHCP service, handing out 192.168.1.0/24 with itself as the gateway. On PC1, renew DHCP.

**Expected:** PC1 still gets a 10.10.10.x lease from R1. The rogue server's offers are dropped because Fa0/3 is untrusted.

**Diagnose:** ASW1: `show ip dhcp snooping`, `show ip dhcp snooping binding`

**Fix:** Remove the server and re-park the port (VLAN 666, shutdown).

**Observed:**

---

## 4. Rogue switch on a user port (BPDU guard)

**Break:** Connect a spare 2960 to ASW1 Fa0/2 in place of PC2.

**Expected:** The port goes err-disabled as soon as it receives a BPDU.

**Diagnose:** ASW1: `show interfaces status err-disabled`, `show logging`

**Fix:** Remove the switch, reconnect PC2, then on Fa0/2 run `shutdown` followed by `no shutdown`.

**Observed:**

---

## 5. Native VLAN mismatch

**Break:** On ASW1 G0/1, set `switchport trunk native vlan 1`.

**Expected:** CDP logs a native VLAN mismatch. Spanning tree may block the port for the affected VLANs.

**Diagnose:** ASW1: `show interfaces trunk`, `show logging`, `show spanning-tree vlan 999`

**Fix:** `switchport trunk native vlan 999`.

**Observed:**

---

## 6. DHCP fails after enabling snooping (option 82)

**Break:** On ASW1, run `ip dhcp snooping information option`. Then on PC1, release and renew DHCP.

**Expected:** PC1 fails to get an address. The access switch now adds option 82 with giaddr 0.0.0.0, and the DSW relay agent drops the request.

**Diagnose:** PC1 falls back to a 169.254.x.x address. R1: `show ip dhcp binding` shows no new lease.

**Fix:** `no ip dhcp snooping information option`, then renew DHCP on PC1.

**Why it matters:** This is one of the most common real-world DHCP snooping mistakes: the feature is turned on and every client loses DHCP.

**Observed:**
