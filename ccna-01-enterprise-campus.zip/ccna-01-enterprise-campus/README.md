# Secure Two-Tier Enterprise Campus

A redundant, segmented campus network with a highly available default gateway, dynamic routing, centralized DHCP, internet access through NAT, and layer 2 security at the edge. It is built in Cisco Packet Tracer, and every device config is committed as plain text so you can read and reproduce it without opening the lab file.

**Part of my networking portfolio:** CCNA (in progress) · AWS Solutions Architect – Associate · CompTIA CySA+ / Security+

---

## The problem

A single-building office needs:

- **Separate networks** for staff, engineering, and guests, plus an isolated management network
- **No single point of failure** between users and the internet edge
- **Guests limited to the internet**, with no path to internal networks
- **Protection at the access layer** against rogue DHCP servers, loops, unauthorized devices, and VLAN hopping
- **Management access only over SSH**, and only from approved networks

## Topology

```mermaid
graph TD
    ISP["ISP<br/>Lo0 8.8.8.8 (simulated internet)"]
    R1["R1 · Edge router<br/>NAT/PAT · DHCP server · OSPF"]
    subgraph DIST["Distribution (L3)"]
        direction LR
        DSW1["DSW1<br/>HSRP active: VLAN 10, 99"] ===|"Po1 · LACP 2x1G trunk"| DSW2["DSW2<br/>HSRP active: VLAN 20, 30"]
    end
    ASW1["ASW1 · Access"]
    ASW2["ASW2 · Access"]
    PC1["PC1 · VLAN 10 Staff"]
    PC2["PC2 · VLAN 20 Engineering"]
    PC3["PC3 · VLAN 10 Staff"]
    PC4["PC4 · VLAN 30 Guest"]

    ISP ---|"203.0.113.0/30"| R1
    R1 ---|"10.0.0.0/30 routed"| DSW1
    R1 ---|"10.0.0.4/30 routed"| DSW2
    DSW1 --- ASW1
    DSW1 --- ASW2
    DSW2 --- ASW1
    DSW2 --- ASW2
    ASW1 --- PC1
    ASW1 --- PC2
    ASW2 --- PC3
    ASW2 --- PC4
```

> Add a screenshot of the Packet Tracer topology to `diagrams/topology.png` once it's built.

| Device | Model (Packet Tracer) | Role |
|---|---|---|
| ISP | ISR4331 | Simulated provider. It has no routes to the campus, so internet reachability proves NAT works |
| R1 | ISR4331 | Internet edge, NAT/PAT, central DHCP server, OSPF default route |
| DSW1, DSW2 | Catalyst 3650-24PS | Inter-VLAN routing, HSRP gateways, STP roots, DHCP relay, guest ACL |
| ASW1, ASW2 | Catalyst 2960-24TT | User access, port security, DHCP snooping, BPDU guard |

## Addressing plan

| VLAN | Name | Subnet | Gateway (HSRP VIP) | DSW1 / DSW2 | HSRP active |
|---|---|---|---|---|---|
| 10 | STAFF | 10.10.10.0/24 | 10.10.10.1 | .2 / .3 | DSW1 |
| 20 | ENGINEERING | 10.10.20.0/24 | 10.10.20.1 | .2 / .3 | DSW2 |
| 30 | GUEST | 10.10.30.0/24 | 10.10.30.1 | .2 / .3 | DSW2 |
| 99 | MGMT | 10.10.99.0/24 | 10.10.99.1 | .2 / .3 | DSW1 |
| 666 | PARKING | none | none | none | Unused ports live here, shut down |
| 999 | NATIVE-UNUSED | none | none | none | Native VLAN on every trunk, carries no traffic |

| Link / device | Address |
|---|---|
| R1 G0/0/0 ↔ ISP | 203.0.113.2/30 ↔ 203.0.113.1/30 |
| R1 G0/0/1 ↔ DSW1 G1/1/1 | 10.0.0.1/30 ↔ 10.0.0.2/30 |
| R1 G0/0/2 ↔ DSW2 G1/1/1 | 10.0.0.5/30 ↔ 10.0.0.6/30 |
| Loopbacks (router IDs) | R1 10.255.255.1 · DSW1 .2 · DSW2 .3 |
| Switch management | ASW1 10.10.99.11 · ASW2 10.10.99.12 |
| DHCP | Pools on R1 for VLANs 10, 20, 30 (.1–.10 reserved); clients reach it through `ip helper-address` on the DSWs |

## What this demonstrates

| Area | Implementation |
|---|---|
| VLANs and trunking | 802.1Q trunks with explicit allowed-VLAN lists, an unused native VLAN, DTP disabled |
| EtherChannel | LACP port channel between the distribution switches |
| Spanning tree | Rapid PVST+, with the root bridge per VLAN placed on that VLAN's active HSRP gateway |
| First-hop redundancy | HSRPv2 with load sharing: each DSW is active for two VLANs and standby for the other two |
| Inter-VLAN routing | Switched virtual interfaces (SVIs) on layer 3 switches |
| Dynamic routing | Single-area OSPF, `passive-interface default`, default route originated from the edge |
| IP services | Centralized DHCP with relay, PAT to a single public address |
| Access security | Port security (sticky MAC, restrict), DHCP snooping, BPDU guard, PortFast, unused ports parked and shut |
| Segmentation | Guest VLAN limited to the internet by an ACL on its SVI |
| Device hardening | SSH v2 only, local AAA, VTY access lists, encrypted secrets, login banner, exec timeouts |

## Repository layout

```
configs/        Paste-ready configuration for every device (credentials are placeholders)
docs/
  build-guide.md        How to build the lab from scratch in Packet Tracer
  design-decisions.md   Why the network is built this way, and what I'd change in production
  verification.md       Test plan: commands, expected results, pass/fail
  troubleshooting.md    Break/fix scenarios: failure injected, symptoms, diagnosis, fix
verification/   Captured show-command output that proves each test passed
scripts/
  sanitize_config.py    Masks passwords and secrets in captured output before it is committed
diagrams/       Topology screenshot
campus.pkt      Packet Tracer file
```

## Reproduce it

1. Follow [docs/build-guide.md](docs/build-guide.md) to place and cable the devices.
2. Paste each file in `configs/` into the matching device's CLI.
3. Run the tests in [docs/verification.md](docs/verification.md).

## Results

| # | Test | Result |
|---|---|---|
| T1 | VLANs and trunks match the design | ☐ |
| T2 | EtherChannel Po1 up with both members bundled | ☐ |
| T3 | STP root placement matches HSRP active | ☐ |
| T4 | HSRP roles and load sharing | ☐ |
| T5 | OSPF adjacencies and default route | ☐ |
| T6 | DHCP leases through relay; snooping bindings | ☐ |
| T7 | Inter-VLAN and cross-switch reachability | ☐ |
| T8 | Internet access through PAT | ☐ |
| T9 | Guest isolation | ☐ |
| T10 | SSH-only management from approved networks | ☐ |
| T11 | Port security learned sticky MACs | ☐ |

Captured evidence for each test is in [`verification/`](verification/). Failure scenarios and recovery are documented in [docs/troubleshooting.md](docs/troubleshooting.md).

## What I'd change in production

Guests would sit in their own VRF or behind a firewall rather than relying on an ACL. User ports would get 802.1X, along with Dynamic ARP Inspection and IP Source Guard. Logins would use AAA against TACACS+ or RADIUS, with central syslog and NTP, and the edge would have a second ISP. See [design-decisions.md](docs/design-decisions.md#what-id-change-in-production).

## Roadmap

- **Project 2:** Branch WAN: multi-site OSPF, IPv6 dual-stack, and standard and extended ACLs
- **Project 3:** Network automation: this campus rebuilt in Cisco Modeling Labs, with configs generated from Jinja2 templates and pushed and verified with Python (Netmiko)
- **Project 4:** Hybrid cloud: on-premises BGP over IPsec VPN to an AWS Transit Gateway
