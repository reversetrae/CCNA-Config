#!/usr/bin/env python3
"""Mask secrets in Cisco IOS output before it is committed to Git.

Type 7 passwords can be reversed in seconds, and type 5/8/9 hashes can be
cracked offline, so neither belongs in a public repository.

Usage:
    python3 scripts/sanitize_config.py verification/*.txt     # edit files in place
    python3 scripts/sanitize_config.py --check verification/*.txt  # report only; exit 1 if secrets found
"""
import argparse
import re
import sys
from pathlib import Path

MASK = "<REDACTED>"

# Each pattern keeps the command keywords (group 1) and replaces the secret value.
PATTERNS = [
    # enable secret 9 $9$...   /   enable password 7 0822455D0A16
    re.compile(r"^(\s*enable (?:secret|password)(?: level \d+)?(?: \d)?) \S+", re.M),
    # username netadmin privilege 15 secret 9 $9$...
    re.compile(r"^(\s*username \S+(?: privilege \d+)? (?:secret|password)(?: \d)?) \S+", re.M),
    # line password under con/vty
    re.compile(r"^(\s*password(?: \d)?) \S+", re.M),
    re.compile(r"^(\s*snmp-server community) \S+", re.M),
    re.compile(r"^(\s*key-string(?: \d)?) \S+", re.M),
    re.compile(r"^(\s*crypto isakmp key(?: \d)?) \S+", re.M),
    re.compile(r"^(\s*pre-shared-key(?: (?:local|remote))?(?: \d)?) \S+", re.M),
    re.compile(r"^(\s*(?:standby|vrrp) \d+ authentication(?: text| md5 key-string(?: \d)?)?) \S+", re.M),
    re.compile(r"^(\s*ip ospf (?:authentication-key|message-digest-key \d+ md5)(?: \d)?) \S+", re.M),
    re.compile(r"^(\s*(?:tacacs-server|radius-server) key(?: \d)?) \S+", re.M),
]


# Values that are already safe to publish: placeholders and masked secrets.
SAFE_VALUE = re.compile(r"^(?:CHANGE_ME\S*|<REDACTED>)$")


def sanitize(text):
    total = 0

    def mask(match):
        nonlocal total
        value = match.group(0)[len(match.group(1)):].strip()
        if SAFE_VALUE.match(value):
            return match.group(0)
        total += 1
        return f"{match.group(1)} {MASK}"

    for pattern in PATTERNS:
        text = pattern.sub(mask, text)
    return text, total


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("files", nargs="+", type=Path)
    parser.add_argument("--check", action="store_true", help="report only, do not modify files")
    args = parser.parse_args()

    found_any = False
    for path in args.files:
        original = path.read_text(encoding="utf-8", errors="replace")
        cleaned, count = sanitize(original)
        if count:
            found_any = True
            if args.check:
                print(f"{path}: {count} secret(s) found")
            else:
                path.write_text(cleaned, encoding="utf-8")
                print(f"{path}: {count} secret(s) masked")
    if args.check and found_any:
        sys.exit(1)


if __name__ == "__main__":
    main()
