# Verification evidence

Captured output for each test in [docs/verification.md](../docs/verification.md).
Name files `T<number>-<device>-<what>.txt`, for example `T4-DSW1-show-standby-brief.txt`.

Before committing, run:

```bash
python3 scripts/sanitize_config.py --check verification/*.txt
```
